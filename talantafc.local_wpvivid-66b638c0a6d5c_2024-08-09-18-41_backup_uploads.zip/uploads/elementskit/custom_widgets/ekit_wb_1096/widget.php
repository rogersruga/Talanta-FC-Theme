<?php

namespace Elementor;

defined('ABSPATH') || exit;

class Ekit_Wb_1096 extends Widget_Base {

	public function get_name() {
		return 'ekit_wb_1096';
	}


	public function get_title() {
		return esc_html__( 'New Widget', 'elementskit-lite' );
	}


	public function get_categories() {
		return ['basic'];
	}


	public function get_icon() {
		return 'eicon-cog';
	}


	protected function register_controls() {

		$this->start_controls_section(
			'content_section_1096_0',
			array(
				'label' => esc_html__( 'Title', 'elementskit-lite' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'ekit_wb_1096_code',
			array(
				'label' => esc_html__( 'Code', 'elementskit-lite' ),
				'type'  => Controls_Manager::CODE,
				'show_label' => true,
				'label_block' => true,
				'language' => 'html',
			)
		);

		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();

		?>
<div id="scoreaxis-widget-514e8" style="border-width:0px;border-color:rgba(0, 0, 0, 0.15);border-style:solid;border-radius:8px;padding:10px;background:rgb(255, 255, 255);width:100%"><iframe id="Iframe" src="https://www.scoreaxis.com/widget/standings-widget/8?autoHeight=0&amp;groupNum=undefined&amp;widgetRows=1%2C1%2C1%2C0%2C0%2C0%2C0%2C1%2C0%2C1&amp;removeBorders=1&amp;links=0&amp;inst=514e8" style="width:100%;height:660px;border:none;transition:all 300ms ease"></iframe><script>window.addEventListener("DOMContentLoaded",event=>{window.addEventListener("message",event=>{if(event.data.appHeight&&"514e8"==event.data.inst){let container=document.querySelector("#scoreaxis-widget-514e8 iframe");container&&(container.style.height=parseInt(event.data.appHeight)+"px")}},!1)});</script></div><div style="font-size: 12px; font-family: Arial, sans-serif; text-align: left;">Data provided by <a target="_blank" href="https://www.scoreaxis.com/">Scoreaxis</a></div>
		<?php
	}


}
