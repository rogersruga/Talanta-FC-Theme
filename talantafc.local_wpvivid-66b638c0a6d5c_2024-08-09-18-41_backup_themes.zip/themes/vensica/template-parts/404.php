<header class="page-header alignwide">
    <h1 class="page-title"><?php esc_html_e( 'Nothing here', 'vensica' ); ?></h1>
</header><!-- .page-header -->

<div class="error-404 not-found default-max-width">
    <div class="page-content">
        <p><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try a search?', 'vensica' ); ?></p>
        <?php get_search_form(); ?>
    </div><!-- .page-content -->
</div><!-- .error-404 -->