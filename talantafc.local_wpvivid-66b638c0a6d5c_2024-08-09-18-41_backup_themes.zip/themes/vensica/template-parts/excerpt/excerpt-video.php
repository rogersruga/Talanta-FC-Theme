<?php
$content = get_the_content();

if ( has_block( 'core/video', $content ) ) {
	vensica_print_first_instance_of_block( 'core/video', $content );
} elseif ( has_block( 'core/embed', $content ) ) {
	vensica_print_first_instance_of_block( 'core/embed', $content );
} else {
	vensica_print_first_instance_of_block( 'core-embed/*', $content );
}

// Add the excerpt.
the_excerpt();
