<?php
the_excerpt();
