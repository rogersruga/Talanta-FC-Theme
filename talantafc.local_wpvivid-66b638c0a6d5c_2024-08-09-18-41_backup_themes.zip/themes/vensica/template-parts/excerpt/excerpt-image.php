<?php
// If there is no featured-image, print the first image block found.
if (
	! vensica_can_show_post_thumbnail() &&
	has_block( 'core/image', get_the_content() )
) {

	vensica_print_first_instance_of_block( 'core/image', get_the_content() );
}

the_excerpt();
