<?php
// Print the full content.
the_content();
