<?php get_header();

wpclubmanager_content();

get_footer();
