<?php $vensica_unique_id = wp_unique_id( 'search-form-' );

$vensica_aria_label = ! empty( $args['aria_label'] ) ? 'aria-label="' . esc_attr( $args['aria_label'] ) . '"' : '';
?>
<form role="search"  method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label for="<?php echo esc_attr( $vensica_unique_id ); ?>"><?php echo esc_html( 'Search&hellip;', 'vensica' ); ?></label>
	<input type="search" id="<?php echo esc_attr( $vensica_unique_id ); ?>" class="search-field" value="<?php echo get_search_query(); ?>" name="s" />
	<input type="submit" class="search-submit" value="<?php echo esc_attr_x( 'Search', 'submit button', 'vensica' ); ?>" />
</form>
