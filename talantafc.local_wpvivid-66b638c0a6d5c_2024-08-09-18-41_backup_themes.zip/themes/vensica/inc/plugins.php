<?php
require get_template_directory() . '/classes/class-tgm-plugin-activation.php';
add_action( 'tgmpa_register', 'themeton_register_required_plugins' );

function themeton_register_required_plugins() {

	/**
	 * Array of plugin arrays. Required keys are name and slug.
	 * If the source is NOT from the .org repo, then source is also required.
	 */
	$plugins = array(
		array(
            'name'              => 'Envato Market',
            'slug'              => 'envato-market',
            'source'            => esc_url('https://github.com/envato/wp-envato-market/archive/master.zip')
        ),
        array(
            'name'               => esc_html__('Elementor', 'vensica'),
            'slug'               => 'elementor',
            'required'           => true,
            'force_activation'   => true,
            'force_deactivation' => false,
        ),
        array(
            'name'               => esc_html__('WP Club Manager', 'vensica'),
            'slug'               => 'wp-club-manager',
            'required'           => true,
            'force_activation'   => false,
            'force_deactivation' => false,
        ),
        array(
            'name'               => esc_html__('WooCommerce', 'vensica'),
            'slug'               => 'woocommerce',
            'required'           => true,
            'force_activation'   => false,
            'force_deactivation' => false,
        ),
        array(
            'name'                  => 'One Click Demo Import',
            'slug'                  => 'one-click-demo-import',
            'required'              => true,
        ),
        array(
            'name'                  => 'SVG Support',
            'slug'                  => 'svg-support',
            'required'              => true,
        ),
        array(
            'name'                  => 'Classic Editor',
            'slug'                  => 'classic-editor',
            'required'              => true,
        ),
	);

    $config = array(
        'id'           => 'themeton-tgmpa',        // Unique ID for hashing notices for multiple instances of TGMPA.
        'default_path' => '',                      // Default absolute path to bundled plugins.
        'menu'         => 'tgmpa-install-plugins', // Menu slug.
        'has_notices'  => true,                    // Show admin notices or not.
        'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
        'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
        'is_automatic' => false,                   // Automatically activate plugins after installation or not.
        'message'      => ''                       // Message to output right before the plugins table.
    );
 
    tgmpa( $plugins, $config );

}
?>