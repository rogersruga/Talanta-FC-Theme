<?php
if ( function_exists( 'register_block_style' ) ) {

	function vensica_register_block_styles() {
		// Columns: Overlap.
		register_block_style(
			'core/columns',
			array(
				'name'  => 'vensica-columns-overlap',
				'label' => esc_html__( 'Overlap', 'vensica' ),
			)
		);

		// Cover: Borders.
		register_block_style(
			'core/cover',
			array(
				'name'  => 'vensica-border',
				'label' => esc_html__( 'Borders', 'vensica' ),
			)
		);

		// Group: Borders.
		register_block_style(
			'core/group',
			array(
				'name'  => 'vensica-border',
				'label' => esc_html__( 'Borders', 'vensica' ),
			)
		);

		// Image: Borders.
		register_block_style(
			'core/image',
			array(
				'name'  => 'vensica-border',
				'label' => esc_html__( 'Borders', 'vensica' ),
			)
		);

		// Image: Frame.
		register_block_style(
			'core/image',
			array(
				'name'  => 'vensica-image-frame',
				'label' => esc_html__( 'Frame', 'vensica' ),
			)
		);

		// Latest Posts: Dividers.
		register_block_style(
			'core/latest-posts',
			array(
				'name'  => 'vensica-latest-posts-dividers',
				'label' => esc_html__( 'Dividers', 'vensica' ),
			)
		);

		// Latest Posts: Borders.
		register_block_style(
			'core/latest-posts',
			array(
				'name'  => 'vensica-latest-posts-borders',
				'label' => esc_html__( 'Borders', 'vensica' ),
			)
		);

		// Media & Text: Borders.
		register_block_style(
			'core/media-text',
			array(
				'name'  => 'vensica-border',
				'label' => esc_html__( 'Borders', 'vensica' ),
			)
		);

		// Separator: Thick.
		register_block_style(
			'core/separator',
			array(
				'name'  => 'vensica-separator-thick',
				'label' => esc_html__( 'Thick', 'vensica' ),
			)
		);

		// Social icons: Dark gray color.
		register_block_style(
			'core/social-links',
			array(
				'name'  => 'vensica-social-icons-color',
				'label' => esc_html__( 'Dark gray', 'vensica' ),
			)
		);
	}
	add_action( 'init', 'vensica_register_block_styles' );
}
