<?php

class Vensica_Customize_Color_Control extends WP_Customize_Color_Control {

	public $type = 'vensica-color';

	public $palette;

	public function enqueue() {
		parent::enqueue();

		// Enqueue the script.
		wp_enqueue_script(
			'vensica-control-color',
			get_theme_file_uri( 'assets/js/palette-colorpicker.js' ),
			array( 'customize-controls', 'jquery', 'customize-base', 'wp-color-picker' ),
			wp_get_theme()->get( 'Version' ),
			false
		);
	}

	public function to_json() {
		parent::to_json();
		$this->json['palette'] = $this->palette;
	}
}
