<?php

/************************************************************************
* Import demo selection
*************************************************************************/
if ( !function_exists( 'vensica_import_files' ) ) {
	function vensica_import_files() {

        $defaults[] = array(
            'import_file_name'           => 'Vensica',
            'categories'                 => 'vensica',
            'import_file_url'            => get_template_directory_uri().'/inc/demo-data/main-content.xml',
            'import_preview_image_url'   => get_template_directory_uri().'/assets/images/screen-image.jpg',
			'import_customizer_file_url' => get_template_directory_uri().'/inc/demo-data/customizer.dat',
            //'import_notice'              => __( 'After you import this demo, you will have to setup the slider separately if it is not imported properly.', 'vensica' ),
            'preview_url'                => 'http://power.themeton.com/vens',
        );

		return $defaults;
	}
}
add_filter( 'pt-ocdi/import_files', 'vensica_import_files' );


if ( !function_exists( 'vensica_after_import' ) ) {
    function vensica_after_import( $selected_import ) {

        $current_key = $selected_import['import_file_name'];

		/************************************************************************
		* Setting Menus
		*************************************************************************/

		$main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );

		if ( isset( $main_menu->term_id ) ) {
			set_theme_mod( 'nav_menu_locations', array(
					'primary' => $main_menu->term_id,
				)
			);
		}

		/************************************************************************
		* Set Home Page & Blog
		*************************************************************************/

		$page = get_page_by_title( 'Home Page' );
		if ( isset( $page->ID ) ) {
			update_option( 'page_on_front', $page->ID );
			update_option( 'show_on_front', 'page' );
		}

		$blogpage = get_page_by_title( 'Blog' );
		if ( isset( $blogpage->ID ) ) {
			update_option( 'page_for_posts', $blogpage->ID );
		}

		/************************************************************************
        * Import slider(s) for the current demo being imported
        *************************************************************************/

        if ( class_exists( 'RevSlider' ) ) {

            if(!RevSliderSlider::alias_exists('main-slider')){
                $slider = new RevSlider();
                $temp_file = download_url(get_template_directory_uri() .'/inc/demo-data/main-slider.zip');
                $slider->importSliderFromPost( true, true, $temp_file );
            }
		}

		/************************************************************************
        * Final cosmetic modifications
        *************************************************************************/
		
		// Elementor Kit Settings

		// Kit importing implementation goes here.
		

		// WooCommerce Settings
		// update_option('woocommerce_default_catalog_orderby', 'date');
		// update_option('woocommerce_catalog_columns', '3');
		// update_option('woocommerce_thumbnail_cropping', 'uncropped');

		// WordPress Club Manager Settings
		if ( !get_option('wpcm_default_club') || get_option('wpcm_default_club') !== '' ):
			update_option('wpcm_default_club', '871');
		endif;

		$hellopost = get_page_by_title( 'Hello world!', OBJECT, 'post' );
		if ( isset( $hellopost->ID ) ) {
			wp_update_post( array(
				'ID' => $hellopost->ID,
				'post_date' => '2021-02-23 18:57:33'
			) );
		}

	}
}
add_action( 'pt-ocdi/after_import', 'vensica_after_import' );